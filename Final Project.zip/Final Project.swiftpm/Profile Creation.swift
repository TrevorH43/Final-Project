import SwiftUI

struct FormCreationView: View {
    @State var fullName:String;
    @State var weightClass:Class;
    @EnvironmentObject var gameState:GameState;
    
    enum Class:String, CaseIterable, Identifiable {
        case Small
        case Medium
        case Heavy
        
        var id:Self {self}
    }
    


    init() {
        fullName = "";
        weightClass = Class.Small
    }
    
    
    var body: some View {
        VStack {
            HStack {
                Image("newbarbell").resizable().frame(width: 64, height: 64);
        Spacer()
        CustomDivider(color:.yellow, height: 8);
            Text("Weight Form")
            Spacer()
        }
        HStack {
            Text("Full Name")
            TextField("Enter your name:", text: $fullName);
        }
            HStack{
                Text("Weight Class:")
                Picker(selection: $weightClass, label: Text("Weight Class")) {
                    ForEach(Class.allCases) {casename in
                        Text(casename.rawValue.capitalized);
                    }
                }.pickerStyle(.segmented)
            }
            HStack {
                Button("Accept"){
                    gameState.fullName = fullName;
                    gameState.weightClass = String.rawValue.capitalized;
                    gameState.weightClass = Int.random(in: 1...3);
                }
            }
    }
}
struct CustomDivider: View {
    var color:Color = .red;
    var height:CGFloat = 8;
    init(color:Color, height:CGFloat){
        self.color = color;
        self.height = height;
    }
    var body: some View {
        Rectangle().fill(color).frame(height: height).edgesIgnoringSafeArea(.horizontal)
    }
}
}

