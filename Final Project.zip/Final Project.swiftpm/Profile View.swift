import SwiftUI

struct ProfileView: View {
    @EnvironmentObject var gameState:GameState;
    var body: some View{
        VStack{
            Text("Profile View");
            HStack {
                Text("Full Name: \(gameState.fullName!)")
            }
            HStack {
                Text("Weight Class: \(gameState.weightClass!)")
            }
            HStack {
                Text("Height Class: \(gameState.heightClass!)")
            }
            HStack { 
                Text("WingSpan: \(gameState.wingSpan!)")
            }
        }
    }
}
